// Job Controller - Handles all job-related operations
const { validationResult } = require('express-validator');

// Mock job database (replace with real database later)
let jobs = [
    // Demo jobs for testing
    {
        id: '1',
        title: 'HVAC - Air Conditioner Not Cooling',
        description: 'My AC unit stopped cooling properly. Warm air is blowing from all vents. Unit is about 5 years old.',
        category: 'hvac',
        urgency: 'urgent',
        status: 'pending',
        clientId: '1',
        clientName: 'John Doe',
        clientEmail: 'client@demo.com',
        address: '123 Main Street, Anytown, ST 12345',
        zipCode: '12345',
        preferredDate: new Date(Date.now() + 24 * 60 * 60 * 1000), // Tomorrow
        estimatedDuration: 120, // 2 hours
        maxBudget: 300,
        photos: [],
        createdAt: new Date(),
        updatedAt: new Date()
    },
    {
        id: '2',
        title: 'Plumbing - Kitchen Sink Clog',
        description: 'Kitchen sink is completely clogged. Water won\'t drain at all. Need urgent help.',
        category: 'plumbing',
        urgency: 'emergency',
        status: 'assigned',
        clientId: '1',
        clientName: 'John Doe',
        clientEmail: 'client@demo.com',
        technicianId: '2',
        technicianName: 'Mike Johnson',
        technicianEmail: 'tech@demo.com',
        address: '123 Main Street, Anytown, ST 12345',
        zipCode: '12345',
        preferredDate: new Date(),
        estimatedDuration: 60, // 1 hour
        maxBudget: 150,
        acceptedAt: new Date(),
        createdAt: new Date(Date.now() - 24 * 60 * 60 * 1000), // Yesterday
        updatedAt: new Date()
    }
];

let jobIdCounter = 3; // Start from 3 since we have 2 demo jobs

// Get all jobs (with filtering)
const getAllJobs = async (req, res) => {
    try {
        const { status, category, zipCode, urgency } = req.query;
        let filteredJobs = [...jobs];

        // Apply filters
        if (status) {
            filteredJobs = filteredJobs.filter(job => job.status === status);
        }
        if (category) {
            filteredJobs = filteredJobs.filter(job => job.category === category);
        }
        if (zipCode) {
            filteredJobs = filteredJobs.filter(job => job.zipCode === zipCode);
        }
        if (urgency) {
            filteredJobs = filteredJobs.filter(job => job.urgency === urgency);
        }

        // Sort by creation date (newest first)
        filteredJobs.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));

        res.json({
            success: true,
            jobs: filteredJobs,
            total: filteredJobs.length
        });
    } catch (error) {
        console.error('Get jobs error:', error);
        res.status(500).json({
            success: false,
            message: 'Server error'
        });
    }
};

// Get jobs for a specific client
const getClientJobs = async (req, res) => {
    try {
        const clientJobs = jobs.filter(job => job.clientId === req.userId);
        
        res.json({
            success: true,
            jobs: clientJobs,
            total: clientJobs.length
        });
    } catch (error) {
        console.error('Get client jobs error:', error);
        res.status(500).json({
            success: false,
            message: 'Server error'
        });
    }
};

// Get jobs for a specific technician
const getTechnicianJobs = async (req, res) => {
    try {
        const techJobs = jobs.filter(job => job.technicianId === req.userId);
        
        res.json({
            success: true,
            jobs: techJobs,
            total: techJobs.length
        });
    } catch (error) {
        console.error('Get technician jobs error:', error);
        res.status(500).json({
            success: false,
            message: 'Server error'
        });
    }
};

// Create a new job (client only)
const createJob = async (req, res) => {
    try {
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            return res.status(400).json({
                success: false,
                message: 'Validation failed',
                errors: errors.array()
            });
        }

        const {
            title,
            description,
            category,
            urgency,
            address,
            zipCode,
            preferredDate,
            estimatedDuration,
            maxBudget
        } = req.body;

        // Get client info (you'll need to implement this based on your user system)
        const clientId = req.userId;
        const clientName = req.userName || 'Unknown Client';
        const clientEmail = req.userEmail || 'unknown@email.com';

        const newJob = {
            id: (jobIdCounter++).toString(),
            title,
            description,
            category,
            urgency: urgency || 'normal',
            status: 'pending',
            clientId,
            clientName,
            clientEmail,
            address,
            zipCode,
            preferredDate: new Date(preferredDate),
            estimatedDuration: parseInt(estimatedDuration) || 60,
            maxBudget: parseFloat(maxBudget) || 0,
            photos: [],
            createdAt: new Date(),
            updatedAt: new Date()
        };

        jobs.push(newJob);

        console.log('✅ New job created:', newJob.title);

        res.status(201).json({
            success: true,
            message: 'Job created successfully',
            job: newJob
        });

    } catch (error) {
        console.error('Create job error:', error);
        res.status(500).json({
            success: false,
            message: 'Server error during job creation'
        });
    }
};

// Accept a job (technician only)
const acceptJob = async (req, res) => {
    try {
        const { jobId } = req.params;
        const technicianId = req.userId;
        const technicianName = req.userName || 'Unknown Technician';
        const technicianEmail = req.userEmail || 'unknown@email.com';

        const job = jobs.find(j => j.id === jobId);

        if (!job) {
            return res.status(404).json({
                success: false,
                message: 'Job not found'
            });
        }

        if (job.status !== 'pending') {
            return res.status(400).json({
                success: false,
                message: 'Job is no longer available'
            });
        }

        // Assign job to technician
        job.status = 'assigned';
        job.technicianId = technicianId;
        job.technicianName = technicianName;
        job.technicianEmail = technicianEmail;
        job.acceptedAt = new Date();
        job.updatedAt = new Date();

        console.log('✅ Job accepted:', job.title, 'by', technicianName);

        res.json({
            success: true,
            message: 'Job accepted successfully',
            job: job
        });

    } catch (error) {
        console.error('Accept job error:', error);
        res.status(500).json({
            success: false,
            message: 'Server error'
        });
    }
};

// Update job status
const updateJobStatus = async (req, res) => {
    try {
        const { jobId } = req.params;
        const { status, notes } = req.body;

        const job = jobs.find(j => j.id === jobId);

        if (!job) {
            return res.status(404).json({
                success: false,
                message: 'Job not found'
            });
        }

        // Check authorization (client can only update their jobs, technician can only update assigned jobs)
        if (job.clientId !== req.userId && job.technicianId !== req.userId) {
            return res.status(403).json({
                success: false,
                message: 'Not authorized to update this job'
            });
        }

        const validStatuses = ['pending', 'assigned', 'in-progress', 'completed', 'cancelled'];
        if (!validStatuses.includes(status)) {
            return res.status(400).json({
                success: false,
                message: 'Invalid status'
            });
        }

        job.status = status;
        job.updatedAt = new Date();

        if (notes) {
            job.notes = notes;
        }

        if (status === 'completed') {
            job.completedAt = new Date();
        }

        console.log('✅ Job status updated:', job.title, 'to', status);

        res.json({
            success: true,
            message: 'Job updated successfully',
            job: job
        });

    } catch (error) {
        console.error('Update job error:', error);
        res.status(500).json({
            success: false,
            message: 'Server error'
        });
    }
};

// Get job details
const getJobDetails = async (req, res) => {
    try {
        const { jobId } = req.params;
        const job = jobs.find(j => j.id === jobId);

        if (!job) {
            return res.status(404).json({
                success: false,
                message: 'Job not found'
            });
        }

        res.json({
            success: true,
            job: job
        });

    } catch (error) {
        console.error('Get job details error:', error);
        res.status(500).json({
            success: false,
            message: 'Server error'
        });
    }
};

module.exports = {
    getAllJobs,
    getClientJobs,
    getTechnicianJobs,
    createJob,
    acceptJob,
    updateJobStatus,
    getJobDetails
};