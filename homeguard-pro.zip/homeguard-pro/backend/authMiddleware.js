const jwt = require('jsonwebtoken');

const JWT_SECRET = 'your-super-secret-jwt-key-change-this-in-production';

// Mock users array - import from userController if needed
// For now, we'll use a simplified approach
const users = [
    {
        id: '1',
        firstName: 'John',
        lastName: 'Doe',
        email: 'client@demo.com',
        role: 'client'
    },
    {
        id: '2',
        firstName: 'Mike',
        lastName: 'Johnson',
        email: 'tech@demo.com',
        role: 'technician'
    },
    {
        id: '3',
        firstName: 'Sarah',
        lastName: 'Admin',
        email: 'admin@demo.com',
        role: 'admin'
    }
];

// Protect middleware - verifies JWT token
const protect = async (req, res, next) => {
    try {
        let token;

        // Get token from Authorization header
        if (req.headers.authorization && req.headers.authorization.startsWith('Bearer')) {
            token = req.headers.authorization.split(' ')[1];
        }

        // Get token from localStorage (for demo purposes)
        if (!token && req.headers['x-auth-token']) {
            token = req.headers['x-auth-token'];
        }

        if (!token) {
            return res.status(401).json({
                success: false,
                message: 'Access denied. No token provided.'
            });
        }

        try {
            // Verify token
            const decoded = jwt.verify(token, JWT_SECRET);
            
            // Find user
            const user = users.find(u => u.id === decoded.userId);
            
            if (!user) {
                return res.status(401).json({
                    success: false,
                    message: 'Invalid token. User not found.'
                });
            }

            // Add user info to request
            req.userId = user.id;
            req.userName = `${user.firstName} ${user.lastName}`;
            req.userEmail = user.email;
            req.userRole = user.role;

            next();
        } catch (error) {
            return res.status(401).json({
                success: false,
                message: 'Invalid token.'
            });
        }

    } catch (error) {
        console.error('Auth middleware error:', error);
        res.status(500).json({
            success: false,
            message: 'Server error in authentication'
        });
    }
};

// Role-based access control
const authorize = (...roles) => {
    return (req, res, next) => {
        if (!roles.includes(req.userRole)) {
            return res.status(403).json({
                success: false,
                message: `Access denied. Role ${req.userRole} is not authorized.`
            });
        }
        next();
    };
};

module.exports = {
    protect,
    authorize
};