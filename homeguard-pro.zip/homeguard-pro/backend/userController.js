const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const { validationResult } = require('express-validator');

// Mock user database with demo users (replace with real database later)
let users = [
    {
        id: '1',
        firstName: 'John',
        lastName: 'Doe',
        email: 'client@demo.com',
        password: 'password123',
        role: 'client'
    },
    {
        id: '2',
        firstName: 'Mike',
        lastName: 'Johnson',
        email: 'tech@demo.com',
        password: 'password123',
        role: 'technician'
    },
    {
        id: '3',
        firstName: 'Sarah',
        lastName: 'Admin',
        email: 'admin@demo.com',
        password: 'password123',
        role: 'admin'
    }
];

let blacklistedTokens = [];
const JWT_SECRET = 'your-super-secret-jwt-key-change-this-in-production';

// Helper function to generate JWT
const generateToken = (userId) => {
    return jwt.sign({ userId }, JWT_SECRET, { expiresIn: '7d' });
};

// Signup controller
const signup = async (req, res) => {
    try {
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            return res.status(400).json({
                success: false,
                message: 'Validation failed',
                errors: errors.array()
            });
        }

        const { firstName, lastName, email, password, role } = req.body;

        // Check if user already exists
        const existingUser = users.find(user => user.email.toLowerCase() === email.toLowerCase());
        if (existingUser) {
            return res.status(400).json({
                success: false,
                message: 'User with this email already exists'
            });
        }

        // Create new user
        const newUser = {
            id: (users.length + 1).toString(),
            firstName,
            lastName,
            email: email.toLowerCase(),
            password, // In production, hash this with bcrypt
            role: role || 'client'
        };

        users.push(newUser);

        // Generate token
        const token = generateToken(newUser.id);

        console.log('✅ New user created:', newUser.email);

        res.status(201).json({
            success: true,
            message: 'User created successfully',
            token,
            user: {
                id: newUser.id,
                email: newUser.email,
                name: `${newUser.firstName} ${newUser.lastName}`,
                role: newUser.role
            }
        });

    } catch (error) {
        console.error('Signup error:', error);
        res.status(500).json({
            success: false,
            message: 'Server error during signup'
        });
    }
};

// Login controller
const login = async (req, res) => {
    try {
        console.log('🔍 Login attempt for:', req.body.email);
        console.log('📊 Available users:', users.map(u => u.email));
        
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            return res.status(400).json({
                success: false,
                message: 'Validation failed',
                errors: errors.array()
            });
        }

        const { email, password } = req.body;

        // Find user by email
        const user = users.find(u => u.email.toLowerCase() === email.toLowerCase());
        
        if (!user) {
            console.log('❌ User not found:', email);
            return res.status(401).json({
                success: false,
                message: 'Invalid email or password'
            });
        }

        // For demo users, check plain text password
        let passwordValid = false;
        
        if (user.password === password) {
            // Plain text password match (for demo users)
            passwordValid = true;
            console.log('✅ Password match for:', email);
        } else {
            // Try bcrypt comparison for hashed passwords
            try {
                passwordValid = await bcrypt.compare(password, user.password);
                console.log('🔐 Bcrypt password check for:', email, passwordValid);
            } catch (error) {
                passwordValid = false;
            }
        }

        if (!passwordValid) {
            console.log('❌ Invalid password for:', email);
            return res.status(401).json({
                success: false,
                message: 'Invalid email or password'
            });
        }

        // Generate JWT token
        const token = generateToken(user.id);

        console.log('✅ Login successful for:', email);

        // Send success response
        res.json({
            success: true,
            message: 'Login successful',
            token: token,
            user: {
                id: user.id,
                email: user.email,
                name: `${user.firstName} ${user.lastName}`,
                role: user.role
            }
        });

    } catch (error) {
        console.error('Login error:', error);
        res.status(500).json({
            success: false,
            message: 'Server error during login'
        });
    }
};

// Logout controller
const logout = async (req, res) => {
    try {
        const token = req.headers.authorization?.replace('Bearer ', '');
        
        if (token) {
            blacklistedTokens.push(token);
        }

        res.json({
            success: true,
            message: 'Logged out successfully'
        });
    } catch (error) {
        console.error('Logout error:', error);
        res.status(500).json({
            success: false,
            message: 'Server error during logout'
        });
    }
};

// Get user profile
const getProfile = async (req, res) => {
    try {
        const user = users.find(u => u.id === req.userId);
        
        if (!user) {
            return res.status(404).json({
                success: false,
                message: 'User not found'
            });
        }

        res.json({
            success: true,
            user: {
                id: user.id,
                email: user.email,
                name: `${user.firstName} ${user.lastName}`,
                role: user.role
            }
        });
    } catch (error) {
        console.error('Get profile error:', error);
        res.status(500).json({
            success: false,
            message: 'Server error'
        });
    }
};

// Update user profile
const updateProfile = async (req, res) => {
    try {
        const user = users.find(u => u.id === req.userId);
        
        if (!user) {
            return res.status(404).json({
                success: false,
                message: 'User not found'
            });
        }

        const { firstName, lastName } = req.body;
        
        if (firstName) user.firstName = firstName;
        if (lastName) user.lastName = lastName;

        res.json({
            success: true,
            message: 'Profile updated successfully',
            user: {
                id: user.id,
                email: user.email,
                name: `${user.firstName} ${user.lastName}`,
                role: user.role
            }
        });
    } catch (error) {
        console.error('Update profile error:', error);
        res.status(500).json({
            success: false,
            message: 'Server error'
        });
    }
};

// Get all users (for testing)
const getAllUsers = async (req, res) => {
    try {
        const userList = users.map(user => ({
            id: user.id,
            email: user.email,
            name: `${user.firstName} ${user.lastName}`,
            role: user.role
        }));

        res.json({
            success: true,
            users: userList,
            total: userList.length
        });
    } catch (error) {
        console.error('Get all users error:', error);
        res.status(500).json({
            success: false,
            message: 'Server error'
        });
    }
};

module.exports = {
    signup,
    login,
    logout,
    getProfile,
    updateProfile,
    getAllUsers
};